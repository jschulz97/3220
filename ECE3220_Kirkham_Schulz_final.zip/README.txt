//////////////////////////////////////////////////////////////////////////////////////////////////////////
///                                    S&K BANKING APPLICATION README                                  ///
//////////////////////////////////////////////////////////////////////////////////////////////////////////

THIS APPLICATION IS BUILT USING WINDOWS SYSTEM CALLS, THEREFORE THE APP WILL ONLY RUN CORRECTLY WHEN
	COMPILED ON WINDOWS.

EXTRACT THE SOURCE FILES TO A SEPARATE DIRECTORY ON YOUR WINDOWS SYSTEM.

IN THE DIRECTORY OF THE EXTRACTED FILES, COMPILE WITH G++ AND THE C++11 LIBRARIES:

				g++ FinalProjectv3.5.cpp -o FinalProjectv3.5 -std=c++11

HEADER FILES ARE INCLUDED UPON COMPILATION BY THE FILE FinalProjectv3.5.cpp.

RUN BY CALLING THE EXECUTABLE:
			
				FinalProjectv3.5.exe